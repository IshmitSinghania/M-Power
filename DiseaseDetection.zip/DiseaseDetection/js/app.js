function hideMessage(){
  document.getElementById("message").classList.add("hidden")
}